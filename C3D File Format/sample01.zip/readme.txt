The following are a set of C3D files that serve as examples
of the correct format for each of the various format types.

Each file has been generated from the same original data.

EB015PI  C3D       156,672  07-08-97 11:05p PC  INT  format
EB015PR  C3D       307,712  07-08-97 11:05p PC  REAL format
EB015SI  C3D       156,672  07-08-97 11:05p SGI INT  format
EB015SR  C3D       307,712  07-08-97 11:05p SGI REAL format
EB015VI  C3D       156,672  07-08-97 11:05p DEC INT  format
EB015VR  C3D       307,712  07-08-97 11:05p DEC REAL format

Additional data samples of many different C3D files are
available by anonymous FTP from the C3D.ORG site at ftp.c3d.org:
        ftp://anonymous:c3dorg@ftp.c3d.org/data/




